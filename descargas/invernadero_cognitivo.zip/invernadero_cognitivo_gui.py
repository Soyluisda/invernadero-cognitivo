# -*- coding: utf-8 -*-
"""
Computación cognitiva en Big Data - Actividad 6
Sistema cognitivo para el monitoreo de un invernadero.

Se completa el proyecto con lo que pidió la empresa:
  1. La variable PH (se suma a temperatura, humedad del aire, humedad del suelo y luz).
  2. Un segundo idioma (inglés) para el reporte del estado del invernadero.

El sistema "razona" en cuatro pasos: percibe (lecturas), interpreta (compara con el rango
del cultivo), aprende del historial (tendencia y lecturas atípicas) y recomienda acciones.
Uso: python invernadero_cognitivo_gui.py   (requiere numpy y matplotlib)

Los rangos por cultivo son valores típicos de referencia; deben confirmarse con un agrónomo.
Los datos son simulados.
"""
import os, csv, math, datetime
import numpy as np
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import matplotlib
matplotlib.use("TkAgg")
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

VARS = ["temp", "hum", "soil", "light", "ph"]

# (ideal_min, ideal_max, critico_min, critico_max)
CULTIVOS = {
    "Tomate":  {"en": "Tomato",     "temp": (18, 27, 10, 35), "hum": (60, 80, 40, 90), "soil": (60, 80, 35, 95),
                "light": (12000, 40000, 5000, 60000), "ph": (6.0, 6.8, 5.0, 7.5)},
    "Lechuga": {"en": "Lettuce",    "temp": (15, 24, 5, 30),  "hum": (60, 75, 40, 90), "soil": (65, 85, 40, 95),
                "light": (8000, 25000, 3000, 45000), "ph": (5.8, 6.5, 5.0, 7.2)},
    "Fresa":   {"en": "Strawberry", "temp": (15, 26, 5, 33),  "hum": (60, 75, 40, 90), "soil": (55, 75, 30, 90),
                "light": (10000, 30000, 4000, 50000), "ph": (5.5, 6.5, 4.8, 7.2)},
}

T = {
    "es": {
        "app": "Invernadero cognitivo: monitoreo con pH y reporte bilingüe",
        "vars": {"temp": "Temperatura (°C)", "hum": "Humedad del aire (%)", "soil": "Humedad del suelo (%)",
                 "light": "Luz (lux)", "ph": "pH"},
        "short": {"temp": "Temperatura", "hum": "Humedad aire", "soil": "Humedad suelo", "light": "Luz", "ph": "pH"},
        "status": {"ok": "Óptimo", "low": "Bajo", "high": "Alto", "crit_low": "Crítico bajo",
                   "crit_high": "Crítico alto", "na": "No aplica (sin sol)"},
        "trend": {"up": "subiendo", "down": "bajando", "flat": "estable"},
        "overall": {"ok": "ÓPTIMO", "warn": "ATENCIÓN", "alert": "ALERTA"},
        "rep_title": "INFORME DEL ESTADO DEL INVERNADERO", "crop": "Cultivo", "when": "Lectura",
        "general": "Estado general", "col": ("Variable", "Valor", "Rango ideal", "Estado", "Tendencia"),
        "recs": "Recomendaciones", "none_rec": "Sin acciones: todas las variables están en rango.",
        "anom": "Lecturas atípicas (revisar el sensor)", "no_anom": "Ninguna.",
        "note": "Nota: los rangos son de referencia y las dosis deben validarse con un agrónomo.",
        "rec": {
            "temp_high": "Abrir las ventanas cenitales y activar los extractores.",
            "temp_low": "Cerrar ventilas y activar calefacción o manta térmica.",
            "hum_high": "Ventilar y reducir el riego por aspersión (riesgo de hongos).",
            "hum_low": "Activar la nebulización para subir la humedad del aire.",
            "soil_high": "Suspender el riego y revisar el drenaje.",
            "soil_low": "Programar un riego ahora.",
            "light_high": "Desplegar la malla de sombreo.",
            "light_low": "Encender la iluminación suplementaria.",
            "ph_high": "El pH está alcalino: bajarlo con ácido diluido (cítrico o fosfórico) en dosis pequeñas y volver a medir; revisar la calidad del agua de riego.",
            "ph_low": "El pH está ácido: subirlo con una base suave en dosis pequeñas y volver a medir; revisar la solución nutritiva.",
        },
        "ui": {"crop": "Cultivo:", "lang": "Idioma del reporte:", "manual": "Lectura manual", "simulate": "Simular 48 horas",
               "analyze": "Analizar lectura manual", "export": "Exportar reporte y datos", "clear": "Reiniciar",
               "report": "Reporte", "charts": "Gráficos", "ok_export": "Se guardaron el reporte (.txt) y las lecturas (.csv).",
               "empty": "Aún no hay lecturas. Presione «Simular 48 horas» o ingrese una lectura manual."},
    },
    "en": {
        "app": "Cognitive greenhouse: pH monitoring and bilingual report",
        "vars": {"temp": "Temperature (°C)", "hum": "Air humidity (%)", "soil": "Soil moisture (%)",
                 "light": "Light (lux)", "ph": "pH"},
        "short": {"temp": "Temperature", "hum": "Air humidity", "soil": "Soil moisture", "light": "Light", "ph": "pH"},
        "status": {"ok": "Optimal", "low": "Low", "high": "High", "crit_low": "Critically low",
                   "crit_high": "Critically high", "na": "N/A (no sun)"},
        "trend": {"up": "rising", "down": "falling", "flat": "stable"},
        "overall": {"ok": "OPTIMAL", "warn": "WARNING", "alert": "ALERT"},
        "rep_title": "GREENHOUSE STATUS REPORT", "crop": "Crop", "when": "Reading",
        "general": "Overall status", "col": ("Variable", "Value", "Ideal range", "Status", "Trend"),
        "recs": "Recommendations", "none_rec": "No actions needed: all variables are within range.",
        "anom": "Unusual readings (check the sensor)", "no_anom": "None.",
        "note": "Note: ranges are reference values and doses must be validated by an agronomist.",
        "rec": {
            "temp_high": "Open the roof vents and turn on the exhaust fans.",
            "temp_low": "Close the vents and turn on heating or a thermal blanket.",
            "hum_high": "Ventilate and reduce sprinkler irrigation (fungus risk).",
            "hum_low": "Turn on misting to raise air humidity.",
            "soil_high": "Stop irrigation and check drainage.",
            "soil_low": "Schedule irrigation now.",
            "light_high": "Deploy the shade screen.",
            "light_low": "Turn on supplemental lighting.",
            "ph_high": "pH is alkaline: lower it with diluted acid (citric or phosphoric) in small doses and measure again; check the irrigation water quality.",
            "ph_low": "pH is acidic: raise it with a mild base in small doses and measure again; check the nutrient solution.",
        },
        "ui": {"crop": "Crop:", "lang": "Report language:", "manual": "Manual reading", "simulate": "Simulate 48 hours",
               "analyze": "Analyze manual reading", "export": "Export report and data", "clear": "Reset",
               "report": "Report", "charts": "Charts", "ok_export": "The report (.txt) and readings (.csv) were saved.",
               "empty": "No readings yet. Press «Simulate 48 hours» or enter a manual reading."},
    },
}

START = datetime.datetime(2026, 10, 14, 0, 0)


# ------------------------------------------------------------------ simulación de sensores
def simular(horas=48, semilla=11):
    rng = np.random.default_rng(semilla)
    datos, humedad_suelo = [], 78.0
    for h in range(horas):
        hd = h % 24
        temp = 23 + 4 * math.sin(2 * math.pi * (hd - 9) / 24) + rng.normal(0, .5)
        if 36 <= h <= 40:
            temp += 6                                           # evento: ola de calor
        hum = 70 - 1.3 * (temp - 23) + rng.normal(0, 2)
        humedad_suelo -= 1.1 + rng.normal(0, .2)
        if humedad_suelo < 58:
            humedad_suelo = 78                                  # riego automático
        luz = max(0.0, 36000 * math.sin(math.pi * (hd - 6) / 12)) + rng.normal(0, 400) if 6 <= hd <= 18 else 0.0
        ph = 6.4 + rng.normal(0, .05)
        if h >= 30:
            ph += 0.07 * (h - 29)                               # evento: el pH se vuelve alcalino
        datos.append({"h": h, "temp": round(temp, 1), "hum": round(hum, 1), "soil": round(humedad_suelo, 1),
                      "light": round(max(luz, 0)), "ph": round(ph, 2)})
    return datos


# ------------------------------------------------------------------ motor cognitivo
def estado_var(var, valor, cultivo, hora):
    if var == "light" and not (8 <= hora % 24 <= 16):   # la luz solo se evalúa con el sol alto
        return "na"
    imin, imax, cmin, cmax = CULTIVOS[cultivo][var]
    if valor < cmin: return "crit_low"
    if valor > cmax: return "crit_high"
    if valor < imin: return "low"
    if valor > imax: return "high"
    return "ok"


def tendencia(hist, var, cultivo, n=6):
    """Pendiente por mínimos cuadrados de las últimas n lecturas, comparada con el ancho del rango ideal."""
    v = [r[var] for r in hist[-n:]]
    if len(v) < 3: return "flat"
    pend = np.polyfit(range(len(v)), v, 1)[0]
    imin, imax = CULTIVOS[cultivo][var][:2]
    cambio = pend * (len(v) - 1)
    umbral = 0.15 * (imax - imin)
    return "up" if cambio > umbral else ("down" if cambio < -umbral else "flat")


def atipica(hist, var, ventana=24):
    """Lectura atípica = salto brusco: el último cambio se aleja más de 4 desviaciones de los cambios
    anteriores. La luz (ciclo día/noche) y la humedad del suelo (riegos) tienen saltos normales y se excluyen."""
    if var in ("light", "soil") or len(hist) < 12: return False
    v = np.array([r[var] for r in hist[-ventana - 1:]], dtype=float)
    d = np.diff(v)
    previos = d[:-1]
    sd = previos.std()
    return sd > 0 and abs(d[-1] - previos.mean()) / sd > 4


def analizar(hist, cultivo):
    ult = hist[-1]
    est = {v: estado_var(v, ult[v], cultivo, ult["h"]) for v in VARS}
    tend = {v: tendencia(hist, v, cultivo) for v in VARS}
    anom = [v for v in VARS if atipica(hist, v)]
    if any(s.startswith("crit") for s in est.values()): general = "alert"
    elif any(s in ("low", "high") for s in est.values()): general = "warn"
    else: general = "ok"
    return est, tend, anom, general


def recomendaciones(est, idioma):
    out = []
    for v in VARS:
        s = est[v]
        if s in ("low", "crit_low"): out.append(T[idioma]["rec"][f"{v}_low"])
        elif s in ("high", "crit_high"): out.append(T[idioma]["rec"][f"{v}_high"])
    return out


def reporte(hist, cultivo, idioma):
    t = T[idioma]
    est, tend, anom, general = analizar(hist, cultivo)
    ult = hist[-1]
    nombre = cultivo if idioma == "es" else CULTIVOS[cultivo]["en"]
    cuando = (START + datetime.timedelta(hours=ult["h"])).strftime("%Y-%m-%d %H:%M")
    L = [t["rep_title"], "=" * len(t["rep_title"]), f"{t['crop']}: {nombre}", f"{t['when']}: {cuando}",
         f"{t['general']}: {t['overall'][general]}", ""]
    c = t["col"]
    L.append(f"{c[0]:<24}{c[1]:>9}  {c[2]:<15}{c[3]:<20}{c[4]}")
    L.append("-" * 82)
    for v in VARS:
        imin, imax = CULTIVOS[cultivo][v][:2]
        rango = f"{imin:g} - {imax:g}"
        valor = f"{ult[v]:g}"
        tr = "-" if est[v] == "na" else t["trend"][tend[v]]
        L.append(f"{t['vars'][v]:<24}{valor:>9}  {rango:<15}{t['status'][est[v]]:<20}{tr}")
    L += ["", t["recs"] + ":"]
    recs = recomendaciones(est, idioma)
    L += [f"  {i}. {r}" for i, r in enumerate(recs, 1)] if recs else ["  " + t["none_rec"]]
    L += ["", t["anom"] + ": " + (", ".join(t["short"][v] for v in anom) if anom else t["no_anom"]), "", t["note"]]
    return "\n".join(L)


# ------------------------------------------------------------------ interfaz gráfica
COLOR = {"ok": "#2e9e5b", "low": "#e0b030", "high": "#e0b030", "crit_low": "#d9534f", "crit_high": "#d9534f", "na": "#999999"}
COLOR_GEN = {"ok": "#2e9e5b", "warn": "#e0b030", "alert": "#d9534f"}


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.geometry("1240x960")
        self.hist = []
        self.cultivo = tk.StringVar(value="Tomate")
        self.idioma = tk.StringVar(value="Español")
        self.entradas = {}
        self._ui()
        self.refrescar_textos()
        self.dibujar()

    def lg(self):
        return "es" if self.idioma.get() == "Español" else "en"

    def _ui(self):
        top = ttk.Frame(self)
        top.pack(fill="x", padx=8, pady=6)
        self.l_crop = ttk.Label(top); self.l_crop.pack(side="left")
        cb = ttk.Combobox(top, textvariable=self.cultivo, values=list(CULTIVOS), width=10, state="readonly")
        cb.pack(side="left", padx=4); cb.bind("<<ComboboxSelected>>", lambda e: self.refrescar())
        self.l_lang = ttk.Label(top); self.l_lang.pack(side="left", padx=(14, 0))
        cl = ttk.Combobox(top, textvariable=self.idioma, values=["Español", "English"], width=9, state="readonly")
        cl.pack(side="left", padx=4); cl.bind("<<ComboboxSelected>>", lambda e: self.refrescar())
        self.b_sim = ttk.Button(top, command=self.simular_48); self.b_sim.pack(side="left", padx=(14, 4))
        self.b_exp = ttk.Button(top, command=self.exportar); self.b_exp.pack(side="left", padx=4)
        self.b_clr = ttk.Button(top, command=self.reiniciar); self.b_clr.pack(side="left", padx=4)

        cuerpo = ttk.Frame(self); cuerpo.pack(fill="both", expand=True, padx=8)
        self.panel = ttk.LabelFrame(cuerpo); self.panel.pack(side="left", fill="y", padx=(0, 8))
        defaults = {"temp": 24, "hum": 70, "soil": 70, "light": 20000, "ph": 6.4}
        self.lbls = {}
        for i, v in enumerate(VARS):
            self.lbls[v] = ttk.Label(self.panel); self.lbls[v].grid(row=i, column=0, sticky="w", padx=6, pady=3)
            e = ttk.Entry(self.panel, width=8); e.insert(0, str(defaults[v])); e.grid(row=i, column=1, padx=6)
            self.entradas[v] = e
        self.b_an = ttk.Button(self.panel, command=self.manual)
        self.b_an.grid(row=len(VARS), column=0, columnspan=2, pady=8, padx=6, sticky="ew")

        self.fig = Figure(figsize=(8.6, 4.0), dpi=90)
        self.canvas = FigureCanvasTkAgg(self.fig, master=cuerpo)
        self.canvas.get_tk_widget().pack(side="left", fill="both", expand=True)
        self.txt = tk.Text(self, height=23, font=("Consolas", 10), bg="#101820", fg="#9ef0b0")
        self.txt.pack(fill="x", padx=8, pady=6)

    def refrescar_textos(self):
        t = T[self.lg()]; u = t["ui"]
        self.title(t["app"]); self.l_crop.config(text=u["crop"]); self.l_lang.config(text=u["lang"])
        self.b_sim.config(text=u["simulate"]); self.b_exp.config(text=u["export"]); self.b_clr.config(text=u["clear"])
        self.panel.config(text=u["manual"]); self.b_an.config(text=u["analyze"])
        for v in VARS: self.lbls[v].config(text=t["vars"][v])

    def refrescar(self):
        self.refrescar_textos(); self.dibujar()

    def simular_48(self):
        self.hist = simular(); self.dibujar()

    def reiniciar(self):
        self.hist = []; self.dibujar()

    def manual(self):
        try:
            lect = {v: float(self.entradas[v].get().replace(",", ".")) for v in VARS}
        except ValueError:
            messagebox.showerror("Error", "Ingrese solo números / Enter numbers only"); return
        lect["h"] = (self.hist[-1]["h"] + 1) if self.hist else 12
        self.hist.append(lect); self.dibujar()

    def dibujar(self):
        t = T[self.lg()]; cult = self.cultivo.get()
        self.fig.clear(); self.txt.delete("1.0", "end")
        if not self.hist:
            ax = self.fig.add_subplot(111); ax.axis("off")
            ax.text(.5, .5, t["ui"]["empty"], ha="center", va="center", wrap=True)
            self.canvas.draw(); self.txt.insert("1.0", t["ui"]["empty"]); return
        est, tend, anom, general = analizar(self.hist, cult)
        hs = [r["h"] for r in self.hist]
        for i, v in enumerate(VARS):
            ax = self.fig.add_subplot(2, 3, i + 1)
            imin, imax, cmin, cmax = CULTIVOS[cult][v]
            ax.axhspan(imin, imax, color="#2e9e5b", alpha=.15)
            ax.plot(hs, [r[v] for r in self.hist], lw=1.2, color="#3f7cac")
            ax.scatter([hs[-1]], [self.hist[-1][v]], color=COLOR[est[v]], zorder=5, s=40)
            ax.set_title(f"{t['short'][v]}: {self.hist[-1][v]:g}", fontsize=9, color=COLOR[est[v]] if est[v] != "ok" else "black")
            ax.tick_params(labelsize=7)
        ax = self.fig.add_subplot(2, 3, 6); ax.axis("off")
        ax.add_patch(matplotlib.patches.Rectangle((.05, .2), .9, .6, color=COLOR_GEN[general], transform=ax.transAxes))
        ax.text(.5, .5, t["overall"][general], ha="center", va="center", fontsize=16, color="white", weight="bold", transform=ax.transAxes)
        self.fig.tight_layout(); self.canvas.draw()
        self.txt.insert("1.0", reporte(self.hist, cult, self.lg()))

    def exportar(self):
        if not self.hist:
            messagebox.showwarning("Aviso", T[self.lg()]["ui"]["empty"]); return
        carpeta = filedialog.askdirectory()
        if not carpeta: return
        for lg in ("es", "en"):
            with open(os.path.join(carpeta, f"reporte_{lg}.txt"), "w", encoding="utf-8") as f:
                f.write(reporte(self.hist, self.cultivo.get(), lg))
        with open(os.path.join(carpeta, "lecturas.csv"), "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f); w.writerow(["hora"] + VARS)
            for r in self.hist: w.writerow([r["h"]] + [r[v] for v in VARS])
        messagebox.showinfo("OK", T[self.lg()]["ui"]["ok_export"])


if __name__ == "__main__":
    App().mainloop()
